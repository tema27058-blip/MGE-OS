# Mna OS / MnaLauncher

Native Android launcher prototype 0.4. See README-RU.md for mobile build, limitations and testing.
